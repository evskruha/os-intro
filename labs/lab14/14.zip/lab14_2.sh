#! /bin/bash
less /usr/share/man/man1/$1.1.gz
